import { A, e } from "./mermaid-parser.core.DntjPeDW.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
