import { I, c } from "./mermaid-parser.core.DntjPeDW.js";
export {
  I as InfoModule,
  c as createInfoServices
};
