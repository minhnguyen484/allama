import { P, a } from "./mermaid-parser.core.DntjPeDW.js";
export {
  P as PacketModule,
  a as createPacketServices
};
